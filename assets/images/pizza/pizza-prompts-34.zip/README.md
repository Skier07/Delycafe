# PROMPT-файлы для 34 пицц Delycafe

Восстановлены по сохранённому generation-plan.json для 33 пицц и составу «50 оттенков сырного» из чата. Это отдельные актуализированные запросы для прозрачных PNG; не дословная копия удалённых файлов.

Каждый TXT содержит название, состав и полный запрос. Прикладывайте фотографию соответствующей пиццы, если она есть, и готовый прозрачный PNG из комплекта как образец ракурса, масштаба и тени.

- Ассорти: 058-assorti — Ассорти — PROMPT.txt
- Барбекью: 059-barbecue — Барбекью — PROMPT.txt
- Вечеринка: 060-vecherinka — Вечеринка — PROMPT.txt
- Гавайская: 061-hawaiian — Гавайская — PROMPT.txt
- Голодный мясник ЧИЛИ: 062-hungry-butcher-chili — Голодный мясник ЧИЛИ — PROMPT.txt
- Голодный мясник: 063-hungry-butcher — Голодный мясник — PROMPT.txt
- Грибная: 064-mushroom — Грибная — PROMPT.txt
- Деревенская с курицей: 065-country-chicken — Деревенская с курицей — PROMPT.txt
- Детская: 066-kids — Детская — PROMPT.txt
- Дьявольская: 067-diavola — Дьявольская — PROMPT.txt
- Жгучая чика: 068-hot-chica — Жгучая чика — PROMPT.txt
- Злодейка: 069-zlodeyka — Злодейка — PROMPT.txt
- Карбонара: 070-carbonara — Карбонара — PROMPT.txt
- Корона: 071-korona — Корона — PROMPT.txt
- Маргарита: 072-margherita — Маргарита — PROMPT.txt
- Мистер Бекон: 073-mister-bacon — Мистер Бекон — PROMPT.txt
- Морская: 074-seafood — Морская — PROMPT.txt
- Мясная: 075-meat — Мясная — PROMPT.txt
- Окей: 076-okay — Окей — PROMPT.txt
- Пицца «Пепперони»: 077-pepperoni — Пицца «Пепперони» — PROMPT.txt
- Просто космос: 078-cosmos — Просто космос — PROMPT.txt
- Прошутто: 079-prosciutto — Прошутто — PROMPT.txt
- Фруктовая: 080-fruit — Фруктовая — PROMPT.txt
- Цезарь: 081-caesar — Цезарь — PROMPT.txt
- Цыпленок барбекью: 082-chicken-bbq — Цыпленок барбекью — PROMPT.txt
- Чикен: 083-chicken — Чикен — PROMPT.txt
- Ягодная: 084-berry — Ягодная — PROMPT.txt
- Морской бриз: 085-sea-breeze — Морской бриз — PROMPT.txt
- Маркиза: 086-marquise — Маркиза — PROMPT.txt
- Фантазия: 087-fantasy — Фантазия — PROMPT.txt
- Сливочный лосось: 088-creamy-salmon — Сливочный лосось — PROMPT.txt
- Пикантный лосось: 089-spicy-salmon — Пикантный лосось — PROMPT.txt
- Угорь с Унаги: 090-unagi — Угорь с Унаги — PROMPT.txt
- 50 оттенков сырного: 50-shades-of-cheese — 50 оттенков сырного — PROMPT.txt
